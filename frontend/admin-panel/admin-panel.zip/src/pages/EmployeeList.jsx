// frontend/admin-panel/src/pages/EmployeeList.jsx

import React, { useEffect, useState } from 'react';
import EmployeeCard from '../components/EmployeeCard';
import adminService from '../services/adminService';
import './EmployeeList.css';

function EmployeeList() {
  const [employees, setEmployees] = useState([]);
  const [loading,   setLoading]   = useState(true);
  const [error,     setError]     = useState(null);

  useEffect(() => {
    async function loadEmployees() {
      try {
        const data = await adminService.getEmployeesWithProfile();
        setEmployees(data);
      } catch (err) {
        console.error('Error loading employees:', err);
        setError('Failed to load employees.');
      } finally {
        setLoading(false);
      }
    }
    loadEmployees();
  }, []);

  return (
    <div className="employee-list">
      <h2>Employees</h2>

      {loading && <div className="loading">Loading employees…</div>}
      {error   && <div className="error">{error}</div>}

      {!loading && !error && (
        <div className="employee-cards">
          {employees.map(emp => (
            <EmployeeCard key={emp._id} employee={emp} />
          ))}
        </div>
      )}
    </div>
  );
}

export default EmployeeList;
