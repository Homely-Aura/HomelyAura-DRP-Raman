// src/index.js
// ─────────────────────────────────────────────────────────
// 1) Grab ?token=… once on page-load and stash it
(() => {
  const params = new URLSearchParams(window.location.search);
  const t = params.get('token');
  if (t) {
    localStorage.setItem('token', t);
    // clean the URL so this only runs once
    window.history.replaceState({}, document.title, window.location.pathname);
  }
})();
// ─────────────────────────────────────────────────────────

import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import { AuthProvider } from './context/AuthContext';
import './index.css';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <AuthProvider>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </AuthProvider>
  </React.StrictMode>
);
