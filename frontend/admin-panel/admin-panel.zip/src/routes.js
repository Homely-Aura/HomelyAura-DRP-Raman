// src/routes.js
import React, { useState } from 'react';
import { Routes, Route, Navigate, Outlet } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import EmployeeList from './pages/EmployeeList';
import EmployeeDetail from './pages/EmployeeDetail';
import SubAdminList from './pages/SubAdminList';
import PendingSignups from './pages/PendingSignups';

const AUTH_URL = process.env.REACT_APP_AUTH_URL || 'http://localhost:3000';

function ProtectedLayout() {
  const { user } = useAuth();

  // ── Sidebar toggle state ───────────────────────────────────────────
  const [open, setOpen] = useState(true);
  const toggleSidebar = () => setOpen(o => !o);
  // ────────────────────────────────────────────────────────────────────

  if (!user) {
    window.location.href =
      `${AUTH_URL}/login?redirect=${encodeURIComponent(window.location.origin)}`;
    return null;
  }
  if (user.role !== 'admin') {
    window.location.href =
      `${AUTH_URL}/logout?redirect=${encodeURIComponent(window.location.origin)}`;
    return null;
  }

  return (
    <div className="app-container">
      {/* Pass toggle into Header */}
      <Header onToggle={toggleSidebar} />

      {/* Add collapsed class when open===false */}
      <div className={`main-content ${open ? '' : 'collapsed'}`}>
        {/* Collapse Sidebar when open===false */}
        <Sidebar collapsed={!open} />

        <div className="page-content">
          <Outlet />
        </div>
      </div>
    </div>
  );
}

export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/*" element={<ProtectedLayout />}>
        <Route index element={<Navigate to="dashboard" replace />} />

        <Route path="dashboard" element={<Dashboard />} />
        <Route path="employees" element={<EmployeeList />} />
        <Route path="employees/:id" element={<EmployeeDetail />} />
        <Route path="subadmins" element={<SubAdminList />} />
        <Route path="pending-signups" element={<PendingSignups />} />

        <Route path="*" element={<Navigate to="dashboard" replace />} />
      </Route>
    </Routes>
  );
}
