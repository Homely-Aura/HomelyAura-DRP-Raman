// src/App.js
import React from 'react';
import AppRoutes from './routes';
import './App.css';

export default function App() {
  return <AppRoutes />;
}
