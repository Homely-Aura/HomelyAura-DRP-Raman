// frontend/admin-panel/src/components/EmployeeDetailModal.jsx

import React, { useState, useEffect } from 'react';
import adminService from '../services/adminService';
import CalendarView from './CalendarView';
import ReportModal  from './ReportModal';
import './EmployeeDetailModal.css';

export default function EmployeeDetailModal({ empId, initialData, onClose }) {
  const [emp,       setEmp]       = useState(initialData);
  const [loading,   setLoading]   = useState(!initialData);
  const [error,     setError]     = useState(null);
  const [showCal,   setShowCal]   = useState(false);
  const [showRpt,   setShowRpt]   = useState(false);
  const [reportDate, setReportDate] = useState(null);

  useEffect(() => {
    if (initialData) return;

    (async () => {
      setLoading(true);
      try {
        const data = await adminService.getEmployee(empId);
        setEmp(data);
      } catch (err) {
        console.error('Error fetching employee:', err);
        setError('Failed to load employee data.');
      } finally {
        setLoading(false);
      }
    })();
  }, [empId, initialData]);

  if (loading) return <div className="employee-detail-loading">Loading…</div>;
  if (error)   return <div className="employee-detail-error">{error}</div>;
  if (!emp)    return <div className="employee-detail-error">No data available.</div>;

  const {
    user: { name, email } = {},
    designation,
    age,
    gender,
    dateOfJoining,
    photo,
  } = emp;

  const backendRoot = process.env.REACT_APP_API_URL.replace(/\/api$/, '');
  const photoUrl = photo
    ? `${backendRoot}/uploads/${photo}`
    : '/assets/placeholder.png';

  const handleDateClick = isoDate => {
    setReportDate(isoDate);
    setShowRpt(true);
  };

  const closeReport = () => {
    setShowRpt(false);
    setReportDate(null);
  };

  return (
    <div className="employee-detail-overlay" role="dialog" aria-modal="true">
      <div className="employee-detail-card">
        <button className="close-btn" onClick={onClose} aria-label="Close">
          ×
        </button>

        <div className="profile-section">
          <img
            src={photoUrl}
            alt={name ? `${name}'s profile` : 'Profile placeholder'}
            className="profile-photo"
          />
          <ul className="profile-info">
            <li><strong>Name:</strong> {name || '—'}</li>
            <li><strong>Email:</strong> {email || '—'}</li>
            <li><strong>Designation:</strong> {designation || '—'}</li>
            <li><strong>Gender:</strong> {gender || '—'}</li>
            <li><strong>Age:</strong> {age ?? '—'}</li>
            <li>
              <strong>Date of Joining:</strong>{' '}
              {dateOfJoining
                ? new Date(dateOfJoining).toLocaleDateString()
                : '—'}
            </li>
          </ul>
        </div>

        <div className="actions">
          <button className="action-btn" onClick={() => setShowCal(true)}>
            Leave Calendar
          </button>
          <button className="action-btn" onClick={() => setShowRpt(true)}>
            Show Report
          </button>
        </div>

        {showCal && (
          <CalendarView
            empId={empId}
            onDateClick={handleDateClick}
            onClose={() => setShowCal(false)}
          />
        )}

        {showRpt && (
          <ReportModal
            empId={empId}
            date={reportDate}
            onClose={closeReport}
          />
        )}
      </div>
    </div>
  );
}
