// src/components/Header.jsx
import React from 'react';
import { useAuth } from '../context/AuthContext';
import { Menu, LogOut } from 'lucide-react';
import './Header.css';

export default function Header({ onToggle }) {
  const { user, logout } = useAuth();

  const handleLogout = () => {
    // 1) clear token + user from context & localStorage
    logout();
    // 2) redirect back to login
    window.location.href = 'http://localhost:3000/login';
  };

  return (
    <header className="header">
      <div className="header-left">
        <Menu className="menu-icon" onClick={onToggle} />
        <span className="logo">Admin Panel</span>
      </div>
      <div className="header-right">
        {user?.username && <span className="username">{user.username}</span>}
        <button className="logout-button" onClick={handleLogout}>
          <LogOut />
          <span>Logout</span>
        </button>
      </div>
    </header>
  );
}
